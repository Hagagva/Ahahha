package com.darktv.app

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class Channel(val name: String, val group: String, val url: String)

class MainActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var etM3uUrl: EditText
    private lateinit var etSearch: EditText
    private lateinit var tvStatus: TextView
    private lateinit var rvChannels: RecyclerView

    private val allChannels = mutableListOf<Channel>()
    private val filteredChannels = mutableListOf<Channel>()
    private lateinit var adapter: ChannelAdapter

    private val defaultM3u = "https://iptv-org.github.io/iptv/categories/sports.m3u"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "VLC/3.0.18 LibVLC/3.0.18")
                .header("Accept", "*/*")
                .build()
            chain.proceed(req)
        }
        .build()

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerView = findViewById(R.id.playerView)
        etM3uUrl = findViewById(R.id.etM3uUrl)
        etSearch = findViewById(R.id.etSearch)
        tvStatus = findViewById(R.id.tvStatus)
        rvChannels = findViewById(R.id.rvChannels)
        val btnLoad = findViewById<Button>(R.id.btnLoad)

        val prefs = getSharedPreferences("DarkTVPrefs", MODE_PRIVATE)
        val savedUrl = prefs.getString("m3u_url", defaultM3u) ?: defaultM3u
        etM3uUrl.setText(savedUrl)

        val dataSourceFactory = OkHttpDataSource.Factory(httpClient)
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build()
        playerView.player = player

        adapter = ChannelAdapter(filteredChannels) { channel ->
            playStream(channel)
        }
        rvChannels.layoutManager = LinearLayoutManager(this)
        rvChannels.adapter = adapter

        btnLoad.setOnClickListener {
            val url = etM3uUrl.text.toString().trim()
            if (url.isNotEmpty()) {
                prefs.edit().putString("m3u_url", url).apply()
                if (url.endsWith(".m3u8") || url.endsWith(".ts") || url.endsWith(".mp4")) {
                    playStream(Channel("بث مباشر مخصص", "Live", url))
                } else {
                    fetchM3u(url)
                }
            }
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                filterChannels(s?.toString() ?: "")
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        fetchM3u(savedUrl)
    }

    private fun fetchM3u(url: String) {
        tvStatus.text = "جاري جلب القنوات بدون قيود CORS..."
        Thread {
            try {
                val request = Request.Builder().url(url).build()
                val response = httpClient.newCall(request).execute()
                val body = response.body?.string() ?: ""
                val parsed = parseM3u(body)

                runOnUiThread {
                    allChannels.clear()
                    allChannels.addAll(parsed)
                    filterChannels(etSearch.text.toString())
                    tvStatus.text = "تم تحميل ${allChannels.size} قناة بنجاح"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvStatus.text = "خطأ في التحميل: ${e.message}"
                }
            }
        }.start()
    }

    private fun parseM3u(content: String): List<Channel> {
        val list = mutableListOf<Channel>()
        val lines = content.lines()
        var currentName = "قناة غير معروفة"
        var currentGroup = "عام"

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXTINF:")) {
                val groupMatch = Regex("group-title=\"([^\"]*)\"").find(trimmed)
                currentGroup = groupMatch?.groupValues?.get(1)?.ifEmpty { "عام" } ?: "عام"
                val commaIndex = trimmed.lastIndexOf(',')
                if (commaIndex != -1 && commaIndex + 1 < trimmed.length) {
                    currentName = trimmed.substring(commaIndex + 1).trim()
                }
            } else if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
                list.add(Channel(currentName, currentGroup, trimmed))
            }
        }
        return list
    }

    private fun filterChannels(query: String) {
        filteredChannels.clear()
        if (query.isEmpty()) {
            filteredChannels.addAll(allChannels)
        } else {
            val q = query.lowercase()
            filteredChannels.addAll(allChannels.filter {
                it.name.lowercase().contains(q) || it.group.lowercase().contains(q)
            })
        }
        adapter.notifyDataSetChanged()
    }

    private fun playStream(channel: Channel) {
        tvStatus.text = "جاري تشغيل: ${channel.name}"
        val mediaItem = MediaItem.fromUri(channel.url)
        player?.setMediaItem(mediaItem)
        player?.prepare()
        player?.play()
        Toast.makeText(this, "تشغيل: ${channel.name}", Toast.LENGTH_SHORT).show()
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }
}

class ChannelAdapter(
    private val items: List<Channel>,
    private val onClick: (Channel) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView = v.findViewById(R.id.tvChannelName)
        val tvGroup: TextView = v.findViewById(R.id.tvChannelGroup)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvGroup.text = item.group
        holder.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = items.size
}
